library(tidyverse)
library(patchwork)
library(scales)
library(data.table)
library(lubridate)
library(hexbin)
library(scico)
library(RColorBrewer)

##Using csv's downloaded from EDI##
papers_out <- read.csv("meth data/GRiMe_sources.csv")
sites_out <- read.csv("meth data/GRiMe_sites.csv")
##using updated csv's
conc_out <- read.csv("meth data/GRiMe_concentrations_v2.csv")
flux_out <- read.csv("meth data/GRiMe_fluxes_v2.csv") 


###number of records of gas concentrations and fluxes, including BDLs and zeros
conc_CH4 <-conc_out %>% 
  filter(!is.na(CH4mean) | !is.na(CH4median))

conc_CO2 <- conc_out %>% 
  filter(!is.na(CO2mean) | !is.na(CO2median))

conc_N2O <- conc_out %>% 
  filter(!is.na(N2Omean) | !is.na(N2Omedian))

d_flux_CH4 <-flux_out %>% 
  filter(!is.na(Diffusive_CH4_Flux_Mean) | !is.na(Diffusive_CH4_Flux_Median))
e_flux_CH4 <-flux_out %>% 
  filter(!is.na(Eb_CH4_Flux_Mean) | !is.na(Eb_CH4_Flux_Median))
t_flux_CH4 <-flux_out %>% 
  filter(!is.na(Total_CH4_Flux_Mean) | !is.na(Total_CH4_Flux_Median))

flux_CO2 <- flux_out %>% 
  filter(!is.na(CO2_Flux_Mean) | !is.na(CO2_Flux_Median))
flux_N2O <- flux_out %>% 
  filter(!is.na(N2O_Flux_Mean) | !is.na(N2O_Flux_Median))



#########
#Figure 6
#########

##Inset-- cumulative data by year of publication
conc_CH4_1 <- conc_CH4[,1:3]
conc_CH4_1 <- left_join(conc_CH4_1, papers_out, by ="Source_ID")

flux_d <- d_flux_CH4[, c(1, 2, 3, 11)]
flux_e <- e_flux_CH4[, c(1, 2, 3, 18)]
flux_t <- t_flux_CH4[, c(1, 2, 3, 25)]

flux_d <-left_join(flux_d, papers_out, by = "Source_ID")
flux_e <-left_join(flux_e, papers_out, by = "Source_ID")
flux_t <-left_join(flux_t, papers_out, by = "Source_ID")

c_year <- conc_CH4_1 %>% count(Pub_year)
c_year$var <-"Concentration"

f_d_year <- count(flux_d, Pub_year) %>% rename(d_count = n)
f_e_year <- count(flux_e, Pub_year) %>% rename(e_count = n)
f_t_year <- count(flux_t, Pub_year) %>% rename(t_count = n)

flux_1 <- full_join(f_d_year, f_e_year, by = "Pub_year")
flux_1 <- full_join(flux_1, f_t_year, by = "Pub_year")

flux_1$n <- rowSums(flux_1[2:4], na.rm = TRUE)
f_year <- flux_1[, c(1, 5)]
f_year$var <- "Flux"

yr <- data.frame(x = 1:53, "Pub_year" = 1970:2022)
c_yr <- left_join(yr, c_year, by = "Pub_year")
c_yr$var[is.na(c_yr$var)] <- "Concentration"
c_yr$n[is.na(c_yr$n)] <- 0
c_yr <- c_yr %>% mutate(cum_count =cumsum(n))
c_yr <-c_yr[, 2:5]

f_yr <- left_join(yr, f_year, by = "Pub_year")
f_yr$var[is.na(f_yr$var)] <- "Flux"
f_yr$n[is.na(f_yr$n)] <- 0
f_yr <- f_yr %>% mutate(cum_count =cumsum(n))
f_yr <- f_yr[, 2:5]

year <- rbind(c_yr, f_yr)
year <- rename(year, year = Pub_year)
year <- rename(year, Variable = var)

c_yr <- mutate(c_yr, pct = (n/24032)*100)
c_yr <- mutate(c_yr, cum_pct = cumsum(pct))

f_yr <- mutate(f_yr, pct = (n/8213)*100)
f_yr <- mutate(f_yr, cum_pct = cumsum(pct))

cum_data <- ggplot(year, aes(x= year, y= cum_count, color = Variable))+
  geom_line(linewidth = 1.2)+
  scale_color_manual(values = c("#ff9f1c", "#a4ac86"))+
  geom_vline(xintercept = 2015)+
  scale_x_continuous(breaks=seq(1970, 2020, 20)) +
  scale_y_continuous(breaks=seq(0, 20000, 10000))+
  xlab("Year")+
  ylab("Cumulative observations")+
  theme_classic() +
  theme(panel.grid.major = element_blank(), panel.grid.minor = element_blank())+
  theme(axis.title = element_text(size = 11))+
  theme(legend.position = "none")

###version of this plot for supplement showing trends by flux type###
##run code up to line ~53 to generate flux1 df 
#also need this:
yr <- data.frame(x = 1:53, "Pub_year" = 1970:2022)

flux_1$d_count[is.na(flux_1$d_count)] <- 0
flux_1$e_count[is.na(flux_1$e_count)] <- 0
flux_1$t_count[is.na(flux_1$t_count)] <- 0
flux_1 <- flux_1 %>% mutate(cum_count_d =cumsum(d_count))
flux_1 <- flux_1 %>% mutate(cum_count_e =cumsum(e_count))
flux_1 <- flux_1 %>% mutate(cum_count_t =cumsum(t_count))

#f_yr <- mutate(f_yr, pct = (n/8213)*100)
#f_yr <- mutate(f_yr, cum_pct = cumsum(pct))

cum_flux <- ggplot(flux_1, aes(x= Pub_year))+
  geom_line(aes(y = cum_count_d), color = "#7570b3", linewidth = 1.2)+
  geom_line(aes(y = cum_count_e), color = "#d95f02", linewidth = 1.2)+
  #geom_line(aes(y = cum_count_t), color = "#E7298A")+
  geom_vline(xintercept = 2015)+
  scale_x_continuous(breaks=seq(1970, 2020, 20)) +
  #scale_y_continuous(breaks=seq(0,2000, 4000, 6000))+
  xlab("Year")+
  ylab("Cumulative observations")+
  theme_classic() +
  theme(panel.grid.major = element_blank(), panel.grid.minor = element_blank())+
  theme(axis.title = element_text(size = 10))

#theme(legend.position = "none")


##main plot-bar chart of observations per site
CH4bysite <- conc_CH4 %>% group_by(Site_ID) %>% 
  summarise(
    count = n()
  )

CH4bysite <- mutate(CH4bysite, n_obs = ifelse(count %in% 101:400, "n >100",
                                              ifelse(count %in% 11:100, "11-100",
                                                     ifelse(count %in% 2:10, "2-10", "n = 1"))))

dflux_bysite <- d_flux_CH4 %>% group_by(Site_ID) %>% 
  summarise(dcount =n())
eflux_bysite <- e_flux_CH4 %>% group_by(Site_ID) %>% 
  summarise(ecount =n())
tflux_bysite <- t_flux_CH4 %>% group_by(Site_ID) %>% 
  summarise(tcount =n())

de_flux <- full_join(dflux_bysite, eflux_bysite, by = "Site_ID")
det_flux <-full_join(de_flux, tflux_bysite, by = "Site_ID") 
det_flux[is.na(det_flux)] = 0

det_flux$sum_count <- det_flux$dcount + det_flux$ecount + det_flux$tcount

det_flux <- mutate(det_flux, f_obs = ifelse(sum_count %in% 101:400, "n >100",
                                            ifelse(sum_count %in% 11:100, "11-100",
                                                   ifelse(sum_count %in% 2:10, "2-10", "n = 1"))))

counts <- full_join(CH4bysite, det_flux, by = "Site_ID")
counts <- mutate(counts, cat = ifelse(is.na(f_obs), "conc",
                                                      ifelse(is.na(n_obs), "flux", "both")))

conc_only <- counts %>% 
  filter(cat == "conc") %>% 
  group_by(n_obs) %>% summarise(count = n())
conc_only <- mutate(conc_only, type = c("conc"))
conc_only <- rename(conc_only, cat = n_obs)

both <- counts %>% 
  filter(cat == "both") %>% 
  group_by(n_obs) %>% summarise(count = n())
both <- mutate(both, type = c("both"))
both <- rename(both, cat = n_obs)
x <- c("n >100", 0, "both")
both <- rbind(both, x)

flux_only <- counts %>% 
  filter(cat == "flux") %>% 
  group_by(f_obs) %>% summarise(count = n())
flux_only <- mutate(flux_only, type = c("flux"))
flux_only <-rename(flux_only, cat = f_obs)
y <- c("n >100", 0, "flux")
flux_only <- rbind(flux_only, y)

b <- rbind(conc_only, both)
b1 <- rbind(b, flux_only)
b1$count <-as.numeric(b1$count)

site_bars <-ggplot(b1, aes(x =reorder(cat, -count), y = count, fill = type)) +
  geom_bar(stat = "identity", color = "black", position=position_dodge())+
  ylab("Number of sites")+
  xlab("Number of observations")+
  scale_y_continuous(expand = c(0,0))+
  theme_classic()+
  #theme_bw() +
  #theme(panel.grid.major = element_blank(), panel.grid.minor = element_blank()) +
  scale_fill_manual(values = c("#936639", "#ff9f1c", "#a4ac86"))+
  theme(axis.text = element_text(size = 11))+
  theme(axis.title = element_text(size = 13))+
  theme(legend.position = "top")+
  theme(legend.title = element_blank())

Fig6 <-site_bars + inset_element(cum_data, left = 0.5, bottom = 0.5, right = 1.01, top = 1.01)
ggsave(Fig5, file = "meth graphs/Fig6_v2.png",
       width = 6, 
       height = 6, 
       units = "in",
       dpi = 500)


######
##fig S1- version of fig. 6 for flux types
######

de_flux_s <- mutate(de_flux, cat = ifelse(is.na(dcount), "eb",
                                      ifelse(is.na(ecount), "diff", "both")))

det_flux_s <-full_join(de_flux_s, tflux_bysite, by = "Site_ID") 
det_flux_s <- det_flux_s %>% replace_na(list(cat = "tot"))
det_flux_s <- det_flux_s %>% replace(is.na(.), 0)


det_flux_s <- mutate(det_flux_s, d_obs = ifelse(dcount %in% 26:100, "26-100",
                                            ifelse(dcount %in% 10:25, "10-25",
                                                   ifelse(dcount %in% 2:9, "2-9", 
                                                          ifelse(dcount == 1,"1", NA)))))

det_flux_s <- mutate(det_flux_s, e_obs = ifelse(ecount %in% 26:100, "26-100",
                                            ifelse(ecount %in% 10:25, "10-25",
                                                   ifelse(ecount %in% 2:9, "2-9", 
                                                          ifelse(ecount == 1, "1", NA)))))

det_flux_s <- mutate(det_flux_s, t_obs = ifelse(tcount %in% 26:100, "26-100",
                                            ifelse(tcount %in% 10:25, "10-25",
                                                   ifelse(tcount %in% 2:9, "2-9", 
                                                          ifelse(tcount == 1, "1", NA)))))

diff_s <- det_flux_s %>% 
  filter(cat == "diff") %>% 
  group_by(d_obs) %>% summarise(count = n())
diff_s <- mutate(diff_s, type = c("diff"))
diff_s <- rename(diff_s, cat = d_obs)

eb_s <- det_flux_s %>% 
  filter(cat == "eb") %>% 
  group_by(e_obs) %>% summarise(count = n())
eb_s <- mutate(eb_s, type = c("eb"))
eb_s <- rename(eb_s, cat = e_obs)

both_s <- det_flux_s %>% 
  filter(cat == "both") %>% 
  group_by(d_obs) %>% summarise(count = n())
both_s <- mutate(both_s, type = c("both"))
both_s <- rename(both_s, cat = d_obs)

tot_s <- det_flux_s %>% 
  filter(cat == "tot") %>% 
  group_by(t_obs) %>% summarise(count = n())
tot_s <- mutate(tot_s, type = c("tot"))
tot_s <- rename(tot_s, cat = t_obs)
x <- c("10-25", 0, "tot")
tot_s <- rbind(tot_s, x)

f <- rbind(diff_s, eb_s)
f1 <- rbind(f, both_s)
f2 <- rbind(f1, tot_s)
f2$count <-as.numeric(f2$count)


site_bars_fluxtype <- ggplot(f2, aes(x =reorder(cat, -count), y = count, fill = type, order = type)) +
  geom_bar(stat = "identity", color = "black", position=position_dodge())+
  ylab("Number of sites")+
  xlab("Number of observations")+
  scale_y_sqrt(expand = c(0,0))+
  #scale_y_continuous(expand = c(0,0))+
  theme_classic()+
  #theme_bw() +
  #theme(panel.grid.major = element_blank(), panel.grid.minor = element_blank()) +
  scale_fill_manual(values = c("#1b9e77", "#7570b3", "#d95f02","#e7298a"))+
  theme(legend.position = "top")+
  theme(legend.title = element_blank())

Fig6supp <-site_bars_fluxtype + inset_element(cum_flux, left = 0.5, bottom = 0.5, right = 1.01, top = 1.01)
ggsave(Fig6supp, file = "meth graphs/Fig6supp.png",
       width = 6, 
       height = 6, 
       units = "in",
       dpi = 500)


#########
#Figure 8
#########
c_sites <- conc_CH4[, c(1,2)]
c_sites <- left_join(c_sites, sites_out, by = "Site_ID")
c_sites1 <- distinct(c_sites) 

#flux_out$Site_ID <- as.numeric(flux_out$Site_ID)
f_sites <- flux_out[, c(1, 2)]
f_sites <- left_join(f_sites, sites_out, by = "Site_ID")
f_sites1 <- distinct(f_sites)

conc_order <- ggplot(c_sites1, aes(x=Strahler_order))+
  geom_bar(width = 0.75, color = "black", fill = "#ff9f1c")+
  scale_x_continuous(name = "", breaks = c(0, 1, 2, 3, 4, 5, 6, 7, 8))+
  scale_y_continuous(limits = c(0, 700), expand = c(0, 0))+
  ylab("Number of concentration sites")+
  theme_classic()+
  theme(axis.text = element_text(size = 10))+
  theme(axis.title = element_text(size = 12))+
  labs(tag = "(a)")

flux_order <- ggplot(f_sites1, aes(x=Strahler_order))+
  geom_bar(width = 0.75, color = "black", fill = "#a4ac86")+
  scale_x_continuous(name = "Strahler Order", breaks = c(0, 1, 2, 3, 4, 5, 6, 7, 8))+
  scale_y_continuous(expand = c(0, 0))+
  ylab("Number of flux sites")+
  theme_classic()+
  theme(axis.text = element_text(size = 10))+
  theme(axis.title = element_text(size = 12))+
  labs(tag = "(c)")

conc_basin2 <- ggplot(c_sites1, aes(x=log10(Basin_size_km2)))+
  geom_histogram(color = "black", fill = "#ff9f1c", bins = 20) +
  theme_classic()+
  ylab("")+
  xlab("")+
  scale_y_continuous(expand = c(0, 0))+
  scale_x_continuous(limits = c(-3.5, 6.9), breaks = seq(-2, 6, by = 2), labels = math_format(10^.x))+
  theme(axis.text = element_text(size = 10))+
  theme(axis.title = element_text(size = 12))+
  labs(tag = "(b)")

flux_basin2 <- ggplot(f_sites1, aes(x=log10(Basin_size_km2)))+
  geom_histogram(color = "black", fill = "#a4ac86", bins = 20) +
  theme_classic()+
  ylab("")+
  xlab(expression(Basin~size~(km^2)))+
  scale_y_continuous(expand = c(0, 0))+
  scale_x_continuous(limits = c(-3.5, 6.9), breaks = seq(-2, 6, by = 2), labels = math_format(10^.x))+
  theme(axis.text = element_text(size = 10))+
  theme(axis.title = element_text(size = 12))+
  labs(tag = "(d)")

site_size2 <-(conc_order + conc_basin2)/(flux_order+ flux_basin2)

ggsave(site_size2, file = "meth graphs/Fig8.png",
       width = 6, 
       height = 6, 
       units = "in",
       dpi = 500)

#regression for site distribution by stream order to inform fig. 8 results
c_sites2 <- c_sites1 %>% group_by(Strahler_order) %>% 
  summarise(count = n()) %>% mutate(log_count = log10(count)) %>% 
  filter(Strahler_order != 0)
f_sites2 <- f_sites1 %>% group_by(Strahler_order) %>% 
  summarise(count = n()) %>% mutate(log_count = log10(count)) %>% 
  filter(Strahler_order != 0)


creg <- lm(c_sites2$log_count ~ c_sites2$Strahler_order)
freg <- lm(f_sites2$log_count ~ f_sites2$Strahler_order)
summary(creg)
summary(freg)


##########################
#Figure 9- see LCL's code
##########################

##########
#Figure 10
##########
#or, more accurately, generating the data needed for Fig. 10

dflux_method <- d_flux_CH4 %>% 
  group_by(Diff_Method) %>% 
  summarise(d_method_count = n())

eflux_method <- e_flux_CH4 %>% 
  group_by(Eb_Method) %>% 
  summarise(e_method_count = n())

tflux_method <- t_flux_CH4 %>% 
  group_by(Total_Method) %>% 
  summarise(t_method_count = n())

k_method <- d_flux_CH4 %>% 
  filter(Diff_Method == "conc+k") %>% 
  group_by(k_Method) %>% 
  summarise(k_Method_count = n())



########
#Table 2
########

#Need to remove BDL values to calculate basic stats.
#Note that the approach used here leaves zero values in the df
#This is a sort of compromise solution to dealing with BDLs- in between
#filtering out all -999999's and 0s vs turning all -999999s into 0.
conc_1 <- na_if(conc_out, -999999.0)
flux_1 <- na_if(flux_out, -999999.0)

conc_1 <- conc_1[, c("CH4mean", "CO2mean", "N2Omean", "WaterTemp_degC", 
                     "Cond_uScm", "pH", "DO_mgL", "DO_percentsat", 
                     "NO3", "NH4", "TN", "SRP", "TP","DOC", "Q")]
conc_1$pH <- as.numeric(conc_1$pH)

stats_conc <-conc_1 %>% 
  summarise(across(CH4mean:Q, list(min = min, max = max, mean = mean, 
                                   median = median, sd = sd), na.rm = TRUE))
write.csv(stats_conc, file = "meth data/stats_conc.csv", row.names = FALSE)

flux_1 <- flux_1[, c("Diffusive_CH4_Flux_Mean", "Eb_CH4_Flux_Mean",
                           "Total_CH4_Flux_Mean", "CO2_Flux_Mean",
                           "N2O_Flux_Mean" )]

stats_flux <- flux_1 %>% 
  summarise(across(Diffusive_CH4_Flux_Mean:N2O_Flux_Mean, 
                   list(min = min, max = max, mean = mean, 
                        median = median, sd = sd), na.rm = TRUE))
write.csv(stats_flux, file = "meth data/stats_flux.csv", row.names = FALSE)



#Counting BDLs for concentrations
CH4_BDLs <- conc_CH4 %>% 
  filter(CH4mean == 0 | CH4mean == "-999999")
CO2_BDLs <- conc_CO2 %>% 
  filter(CO2mean == 0 | CO2mean == "-999999")
N2O_BDLs <- conc_N2O %>% 
  filter(N2Omean == 0 | N2Omean == "-999999")

#Counting 0, BDL, and negative fluxes
d_flux_1 <- d_flux_CH4 %>% 
  filter(Diffusive_CH4_Flux_Mean <= 0)
e_flux_1 <- e_flux_CH4 %>%
  filter(Eb_CH4_Flux_Mean <= 0)
t_flux_1 <- t_flux_CH4 %>% 
  filter(Total_CH4_Flux_Mean <= 0) 
flux_CO2_1 <- flux_CO2 %>%
  filter(CO2_Flux_Mean <= 0)
flux_N2O_1 <- flux_N2O  %>%
  filter(N2O_Flux_Mean<= 0)

#Counting just 0 and BDL fluxes
d_flux_2 <- d_flux_CH4 %>% 
  filter(Diffusive_CH4_Flux_Mean == -999999 |Diffusive_CH4_Flux_Mean == 0) 
e_flux_2 <- e_flux_CH4 %>% 
  filter(Eb_CH4_Flux_Mean == -999999 | Eb_CH4_Flux_Mean ==0) 
t_flux_2 <- t_flux_CH4 %>% 
  filter(Total_CH4_Flux_Mean == -999999 | Total_CH4_Flux_Mean ==0) 
flux_CO2_2 <- flux_CO2 %>%
  filter(CO2_Flux_Mean == -999999 | CO2_Flux_Mean == 0)
flux_N2O_2 <- flux_N2O  %>%
  filter(N2O_Flux_Mean == -999999 | N2O_Flux_Mean == 0)



##########
#Figure 11
##########

CH4hist <- ggplot(conc_out, aes(x=CH4mean)) + 
  geom_histogram(bins = 30, color = "black", linewidth = 0.2, fill = "#ff9f1c")+
  geom_vline(xintercept = 0.0033, linetype = "dashed")+
  scale_x_log10(labels = trans_format("log10", math_format(10^.x)))+
  scale_y_continuous(limits = c(0, 3400), expand = c(0,0))+
  xlab(~ paste("CH"[4] , " (", mu, "mol L"^-1, ")" ))+
  #xlab("")+
  #ylab("")+
  ylab("Count")+
  theme_classic()+
  theme(text = element_text(size = 7))+
  theme(axis.line.x.bottom = element_line())+
  theme(axis.ticks.x = element_line())+
  theme(axis.line.y.left = element_line())+
  theme(axis.ticks.y = element_line())+
  labs(tag = "(a)")

CO2hist <- ggplot(conc_out, aes(x=CO2mean)) + 
  geom_histogram(bins = 30, color = "black", linewidth = 0.2, fill = "#ff9f1c")+
  scale_x_log10(limits = c(1, 10000), labels = trans_format("log10", math_format(10^.x))) +
  scale_y_continuous(limits = c(0, 3010), breaks = seq(0, 3000,by = 1000), expand = c(0,0))+
  theme(axis.title.y = element_blank())+
  xlab(~ paste("CO"[2] , " (", mu, "mol L"^-1, ")" ))+
  #xlab(~ paste("Concentration", " (", mu, "mol L"^-1, ")" ))+
  #xlab("")+
  ylab("")+
  #ylab("Number of observations")+
  geom_vline(xintercept = 19.8, linetype = "dashed")+
  theme_classic()+
  theme(text = element_text(size = 7))+
  theme(axis.line.x.bottom=element_line())+
  theme(axis.ticks.x = element_line())+
  theme(axis.line.y.left=element_line())+
  theme(axis.ticks.y = element_line())+
  labs(tag = "(b)")

N2Ohist <- ggplot(conc_out, aes(x=N2Omean)) + 
  geom_histogram(bins = 30, linewidth = 0.2, color = "black", fill = "#ff9f1c")+
  scale_x_log10(limits = c(0.001, 1),labels = trans_format("log10", math_format(10^.x)))+ 
  theme(axis.title.y = element_blank())+
  xlab(~ paste("N"[2], "O" , " (", mu, "mol L"^-1, ")" ))+
  #xlab(~ paste("Concentration", " (", mu, "mol L"^-1, ")" ))+
  #xlab("")+
  ylab("")+
  scale_y_continuous(limits = c(0, 1200), breaks = seq(0, 1000,by = 500), expand = c(0,0))+
  geom_vline(xintercept = 0.012, linetype = "dashed")+
  theme_classic()+
  theme(text = element_text(size = 7))+
  theme(axis.line.x.bottom=element_line())+
  theme(axis.ticks.x = element_line())+
  theme(axis.line.y.left=element_line())+
  theme(axis.ticks.y = element_line())+
  labs(tag = "(c)")

conc_hist <- CH4hist + CO2hist + N2Ohist
ggsave("conc_hist_v.png", 
       width = 6, 
       height = 2, 
       units = "in",
       dpi = 500)

CH4_dflux_hist <- ggplot(flux_out, aes(x=Diffusive_CH4_Flux_Mean)) + 
  geom_histogram(bins = 30, color = "black", linewidth = 0.2,fill = "#a4ac86") +
  scale_x_log10(limits = c(0.0001, 1000), labels = trans_format("log10", math_format(10^.x)))+
  scale_y_continuous(limits = c(0, 910), breaks = seq(0, 800,by = 400), expand = c(0,0))+
  xlab(expression(CH[4]~diffusive~flux~(mmol~m^-2~d^-1)))+
  #xlab("")+
  ylab("Count")+
  theme_classic()+
  theme(text = element_text(size = 7))+
  theme(axis.line.x.bottom=element_line())+
  theme(axis.ticks.x = element_line())+
  theme(axis.line.y.left=element_line())+
  theme(axis.ticks.y = element_line())+
  labs(tag = "(d)")

CO2flux_hist <- ggplot(flux_out, aes(x=CO2_Flux_Mean)) + 
  geom_histogram(bins = 30, color = "black", linewidth = 0.2,fill = "#a4ac86") +
  scale_x_log10(limits = c(0.09, 7500), labels = trans_format("log10", math_format(10^.x))) +
  scale_y_continuous(limits = c(0,525), breaks = seq(0, 500, by =250), expand = c(0,0))+
  theme(axis.title.y = element_blank())+
  xlab(expression(CO[2]~flux~(mmol~m^-2~d^-1)))+
  #xlab(expression(Diffusive~flux~(mmol~m^-2~d^-1)))+
  #xlab("")+
  ylab("")+
  theme_classic()+
  theme(text = element_text(size = 7))+
  theme(axis.line.x.bottom=element_line())+
  theme(axis.ticks.x = element_line())+
  theme(axis.line.y.left=element_line())+
  theme(axis.ticks.y = element_line())+
  labs(tag = "(e)")

N2Oflux_hist <- ggplot(flux_out, aes(x=N2O_Flux_Mean)) + 
  geom_histogram(bins = 30, color = "black", linewidth = 0.2,fill = "#a4ac86") +
  scale_x_log10(labels = trans_format("log10", math_format(10^.x))) +
  scale_y_continuous(limits = c(0, 240), breaks = seq(0, 200, by = 100), expand = c(0,0))+
  theme(axis.title.y = element_blank())+
  #xlab("")+
  xlab(expression(N[2]*O~flux~(mmol~m^-2~d^-1)))+
  ylab("")+
  theme_classic()+
  theme(text = element_text(size = 7))+
  theme(axis.line.x.bottom=element_line())+
  theme(axis.ticks.x = element_line())+
  theme(axis.line.y.left=element_line())+
  theme(axis.ticks.y = element_line())+
  theme(axis.ticks.length = unit(.25, "cm"))+
  labs(tag = "(f)")

flux_hist <- CH4_dflux_hist + CO2flux_hist + N2Oflux_hist

cf <- conc_hist/flux_hist

CH4_eflux_hist <- ggplot(flux_out, aes(x = Eb_CH4_Flux_Mean)) + 
  geom_histogram(bins = 30, color = "black", linewidth = 0.2,fill = "#a4ac86") +
  scale_x_log10(limits = c(0.0001, 1000), labels = trans_format("log10", math_format(10^.x)))+
  scale_y_continuous(limits = c(0, 75), breaks = seq(0, 75,by = 25), expand = c(0,0))+
  xlab(expression(CH[4]~ebullitive~flux~(mmol~m^-2~d^-1)))+
  #xlab("")+
  ylab("Count")+
  theme_classic()+
  theme(text = element_text(size = 7))+
  theme(axis.line.x.bottom=element_line())+
  theme(axis.ticks.x = element_line())+
  theme(axis.line.y.left=element_line())+
  theme(axis.ticks.y = element_line())+
  labs(tag = "(g)")

CH4_tflux_hist <- ggplot(flux_out, aes(x = Total_CH4_Flux_Mean)) + 
  geom_histogram(bins = 30, color = "black", linewidth = 0.2, fill = "#a4ac86") +
  scale_x_log10(limits = c(0.0001, 1000), labels = trans_format("log10", math_format(10^.x)))+
  scale_y_continuous(limits = c(0, 75), breaks = seq(0, 75,by = 25), expand = c(0,0))+
  xlab(expression(CH[4]~total~flux~(mmol~m^-2~d^-1)))+
  #xlab("")+
  #ylab("Count")+
  ylab("")+
  theme_classic()+
  theme(text = element_text(size = 7))+
  theme(axis.line.x.bottom=element_line())+
  theme(axis.ticks.x = element_line())+
  theme(axis.line.y.left=element_line())+
  theme(axis.ticks.y = element_line())+
  labs(tag = "(h)")

etflux <- plot_spacer() + CH4_eflux_hist + CH4_tflux_hist + plot_spacer()+
  plot_layout(widths = (c(1, 2, 2, 1)))

all <- cf/etflux
ggsave("meth graphs/Fig11.png", 
       width = 6, 
       height = 6, 
       units = "in",
       dpi = 500)


###########
#Figure 12
###########

#average by site: concentration
conc_CH4_2 <- conc_out %>% 
  filter(!is.na(CH4mean)) %>% 
  filter(CH4mean >0)

CH4_siteavg_conc <- conc_CH4_2 %>% 
  group_by(Site_ID) %>%
  summarise(avg = mean(CH4mean, na.rm = TRUE))

CH4_siteavg_conc <- left_join(CH4_siteavg_conc, sites_out, by = "Site_ID") 

#average by site:flux

#this plot is based on site means, so need to remove rows that have medians
#but not means
CH4_siteavg_flux <- d_flux_CH4 %>% 
  filter(Diffusive_CH4_Flux_Mean > -999999) %>%
  group_by(Site_ID) %>%
  summarise(AvgFlux = mean(Diffusive_CH4_Flux_Mean, na.rm = TRUE))

CH4_siteavg_flux <- left_join(CH4_siteavg_flux, sites_out, by = "Site_ID")



##borrowing from GRR's code '3_figures_datapaper.R' But note that I'm 
##using site averages instead of all observations, except for the "meth_q
##plot 
conc_lat <- ggplot(CH4_siteavg_conc, aes(x = Latitude, y = avg))+
  geom_point(color = "#ff9f1c", alpha = .3)+
  scale_x_continuous(limits = c(-40, 90), breaks = seq(-25, 75,by = 25))+
  scale_y_log10(limits=c(0.0001, 100), 
                label=trans_format("log10",math_format(10^.x)))+
  theme_classic()+
  theme(text = element_text(size = 8))+
  ylab(~ paste("CH"[4] , " (", mu, "mol L"^-1, ")" ))+
  xlab("")+
  labs(tag = "(a)")


conc_catchment <- ggplot(CH4_siteavg_conc, aes(Basin_size_km2, avg))+
  geom_point(color = "#ff9f1c", alpha = .3)+
  scale_y_log10(limits=c(0.0001, 100), 
                label=trans_format("log10",math_format(10^.x)))+
  scale_x_log10(label=trans_format("log10",math_format(10^.x)))+
  theme_classic()+
  theme(text = element_text(size = 8))+
  #ylab(~ paste("CH"[4] , " (", mu, "mol L"^-1, ")" ))+
  ylab("")+
  xlab("")+
  labs(tag = "(b)")

conc_order <- ggplot(CH4_siteavg_conc, aes(Strahler_order, avg, group = Strahler_order))+
  geom_jitter(color = "#ff9f1c", alpha = .3)+
  geom_boxplot(outlier.shape = NA, fill = NA)+
  scale_y_log10(limits=c(0.0001, 100),
                label=trans_format("log10",math_format(10^.x)))+
  scale_x_continuous(breaks = 0:8)+
  theme_classic()+
  theme(text = element_text(size = 8))+
  labs(x= "", y = "")+
  labs(tag = "(c)")

##flux plots by site attribute
flux_lat <- ggplot(CH4_siteavg_flux, aes(x = Latitude, y = AvgFlux))+
  geom_point(color = "#a4ac86", alpha = .3)+
  scale_x_continuous(limits = c(-40, 90), breaks = seq(-25, 75,by = 25))+
  scale_y_log10(limits=c(0.0001, 1000), 
                label=trans_format("log10",math_format(10^.x)))+
  theme_classic()+
  theme(text = element_text(size = 8))+
  ylab(expression(CH[4]~emissions~(mmol~m^-2~d^-1)))+
  xlab("Latitude")+
  labs(tag = "(d)")


flux_catchment <- ggplot(CH4_siteavg_flux, aes(Basin_size_km2, AvgFlux))+
  geom_point(color = "#a4ac86", alpha = .3)+
  scale_y_log10(limits=c(0.0001, 100), 
                label=trans_format("log10",math_format(10^.x)))+
  scale_x_log10(label=trans_format("log10",math_format(10^.x)))+
  theme_classic()+
  theme(text = element_text(size = 8))+
  #ylab(~ paste("CH"[4] , " (", mu, "mol L"^-1, ")" ))+
  ylab("")+
  xlab(expression(Basin~area~(km^2)))+
  labs(tag = "(e)")

flux_order <- ggplot(CH4_siteavg_flux, aes(Strahler_order, AvgFlux, group = Strahler_order))+
  geom_jitter(color = "#a4ac86", alpha = .3)+
  geom_boxplot(outlier.shape = NA, fill = NA)+
  scale_y_log10(limits=c(0.0001, 100),
                label=trans_format("log10",math_format(10^.x)))+
  scale_x_continuous(breaks = 0:8)+
  theme_classic()+
  theme(text = element_text(size = 8))+
  labs(x= "Strahler order", y = "")+
  labs(tag = "(f)")

conc_site_plots <- conc_lat + conc_catchment + conc_order
flux_site_plots <- flux_lat + flux_catchment + flux_order
conc_flux_site <- conc_site_plots/flux_site_plots
ggsave("meth graphs/Fig12.png", 
       width = 6, 
       height = 4, 
       units = "in",
       dpi = 500)


#concentration basic stats
lat_reg <-lm(CH4_siteavg_conc$avg ~ abs(CH4_siteavg_conc$Latitude))
basin_reg <-lm(CH4_siteavg_conc$avg ~ CH4_siteavg_conc$Basin_size_km2)

kw_order <- kruskal.test(avg ~ Strahler_order, data = CH4_siteavg_conc)
conc_pairs_order <- pairwise.wilcox.test(CH4_siteavg_conc$avg, CH4_siteavg_conc$Strahler_order,
                                  p.adjust.method = "BH")


#flux basic stats
lat_flux_reg <-lm(CH4_siteavg_flux$AvgFlux ~ abs(CH4_siteavg_flux$Latitude))
basin_flux_reg <-lm(CH4_siteavg_flux$AvgFlux ~ CH4_siteavg_flux$Basin_size_km2)

kw_order_flux <- kruskal.test(AvgFlux ~ Strahler_order, data = CH4_siteavg_flux)
flux_pairs_order <- pairwise.wilcox.test(CH4_siteavg_flux$AvgFlux, CH4_siteavg_flux$Strahler_order,
                                        p.adjust.method = "BH")


##########
#Figure 13 
##########

#conc_CH4_2 defined for fig.11


DO_conc <- ggplot(conc_CH4_2, aes(x=DO_mgL, y=CH4mean)) +
  geom_bin2d(bins = 80) +
  scale_fill_scico(limits = c(1, 30),palette = "davos") +
  scale_y_log10(limits = c(0.0001, 100), labels = trans_format("log10", math_format(10^.x)))+
  #xlab("Dissolved Oxygen (mg/L)")+
  xlab("")+
  ylab(~ paste("CH"[4] , " (", mu, "mol L"^-1, ")" ))+
  ggtitle("(a)")+
  theme_classic()+
  theme(text = element_text(size = 7))+
  theme(axis.line.x.bottom=element_line())+
  theme(axis.ticks.x = element_line())+
  theme(axis.line.y.left=element_line())+
  theme(axis.ticks.y = element_line())+
  theme(legend.position = "none")

#remove -999999's (BDLs) and 3 insane outliers
conc_CH4_DOC <- conc_CH4_2 %>%
  filter(DOC >0 & DOC < 50000)

DOC_conc <- ggplot(conc_CH4_DOC, aes(x=DOC, y=CH4mean)) +
  geom_bin2d(bins = 100) +
  scale_fill_scico(limits = c(1, 30),palette = "davos") +
  scale_x_log10(limits = c(5, 10000), labels = trans_format("log10", math_format(10^.x)))+
  scale_y_log10(limits = c(0.0001, 100), labels = trans_format("log10", math_format(10^.x)))+
  xlab("")+
  ylab("")+
  ggtitle("(b)")+
  theme_classic()+
  theme(text = element_text(size = 7))+
  theme(axis.line.x.bottom=element_line())+
  theme(axis.ticks.x = element_line())+
  theme(axis.line.y.left=element_line())+
  theme(axis.ticks.y = element_line())+
  theme(legend.position = "none")

#remove -999999's (BDLs)
conc_CH4_TN <- conc_CH4_2 %>% 
  filter(TN > 0)

TN_conc <- ggplot(conc_CH4_TN, aes(x=TN, y=CH4mean)) +
  geom_bin2d(bins = 80) +
  scale_fill_scico(limits = c(1, 30),palette = "davos") +
  scale_x_log10(limits = c(1, 10000), labels = trans_format("log10", math_format(10^.x)))+
  scale_y_log10(limits = c(0.0001, 100), labels = trans_format("log10", math_format(10^.x)))+
  #xlab(~ paste("Total Nitrogen (", mu, "mol L"^-1, ")" ))+
  xlab("")+
  #ylab(~ paste("CH"[4] , " (", mu, "mol L"^-1, ")" ))+
  ylab("")+
  ggtitle("(c)")+
  theme_classic()+
  theme(text = element_text(size = 7))+
  theme(axis.line.x.bottom=element_line())+
  theme(axis.ticks.x = element_line())+
  theme(axis.line.y.left=element_line())+
  theme(axis.ticks.y = element_line())+
  theme(legend.position = "none")


conc_CH4_TP <- conc_CH4_2 %>% 
  filter(TP >0)

TP_conc <- ggplot(conc_CH4_TP, aes(x=TP, y=CH4mean)) +
  geom_bin2d(bins = 70) +
  scale_fill_scico(limits = c(1, 30),palette = "davos") +
  scale_x_log10(limits = c(0.01, 1000), labels = trans_format("log10", math_format(10^.x)))+
  scale_y_log10(limits = c(0.0001, 100), labels = trans_format("log10", math_format(10^.x)))+
  #xlab(~ paste("Total Phosphorus (", mu, "mol L"^-1, ")" ))+
  xlab("")+
  #ylab(~ paste("CH"[4] , " (", mu, "mol L"^-1, ")" ))+
  ylab("")+
  ggtitle("(d)")+
  theme_classic()+
  theme(text = element_text(size = 7))+
  theme(axis.line.x.bottom=element_line())+
  theme(axis.ticks.x = element_line())+
  theme(axis.line.y.left=element_line())+
  theme(axis.ticks.y = element_line())+
  theme(legend.key.size = unit(0.275, 'cm'))



all_conc_plots <- DO_conc + DOC_conc + TN_conc + TP_conc +
  plot_layout(ncol = 4)


####non-binned alternatives for fluxes
flux_supplemented <- flux_out[, c(2, 4, 5, 11)]
conc_11_12 <- conc_CH4[, c(1:5, 13, 30, 32, 35, 37, 38)]
conc_11_12 <- left_join(conc_11_12, sites_out, by = "Site_ID")

flux_supp2 <- left_join(flux_supplemented, conc_11_12, 
                        by = c("Site_ID", "Date_start"))

DO_flux <- ggplot(flux_supp2, aes(x=DO_mgL, y=Diffusive_CH4_Flux_Mean)) +
  #geom_point(size = 0.5, color = "#a4ac86", alpha = 0.15)+
  geom_bin2d(bins = 70) +
  scale_fill_scico(limits = c(1, 15),palette = "bamako") +
  scale_y_log10(limits = c(0.0001, 100), labels = trans_format("log10", math_format(10^.x)))+
  #xlab("Dissolved Oxygen (mg/L)")+
  xlab(expression(O[2]~(mg/L)))+
  ylab(expression(CH[4]~diffusive~flux~(mmol~m^-2~d^-1)))+
  ggtitle("(e)")+
  theme_classic()+
  theme(text = element_text(size = 7))+
  theme(axis.line.x.bottom=element_line())+
  theme(axis.ticks.x = element_line())+
  theme(axis.line.y.left=element_line())+
  theme(axis.ticks.y = element_line())+
  theme(legend.position = "none")


DOC_flux <- ggplot(flux_supp2, aes(x=DOC, y=Diffusive_CH4_Flux_Mean)) +
  #geom_point(size = 0.5, color = "#a4ac86", alpha = 0.15)+
  geom_bin2d(bins = 70) +
  scale_fill_scico(limits = c(1, 15),palette = "bamako") +
  scale_x_log10(limits = c(1, 10000), labels = trans_format("log10", math_format(10^.x)))+
  scale_y_log10(limits = c(0.0001, 100), labels = trans_format("log10", math_format(10^.x)))+
  xlab(~ paste("DOC (", mu, "mol L"^-1, ")" ))+
  #ylab(expression(CH[4]~diffusive~flux~(mmol~m^-2~d^-1)))+
  ylab("")+
  ggtitle("(f)")+
  theme_classic()+
  theme(text = element_text(size = 7))+
  theme(axis.line.x.bottom=element_line())+
  theme(axis.ticks.x = element_line())+
  theme(axis.line.y.left=element_line())+
  theme(axis.ticks.y = element_line())+
  theme(legend.position = "none")

TN_flux <- ggplot(flux_supp2, aes(x=TN, y=Diffusive_CH4_Flux_Mean)) +
  #geom_point(size = 0.5, color = "#a4ac86", alpha = 0.15)+
  geom_bin2d(bins = 60) +
  scale_fill_scico(limits = c(1, 15),palette = "bamako") +
  scale_x_log10(limits = c(1, 10000), labels = trans_format("log10", math_format(10^.x)))+
  scale_y_log10(limits = c(0.0001, 100), labels = trans_format("log10", math_format(10^.x)))+
  xlab(~ paste("Total N (", mu, "mol L"^-1, ")" ))+
  #ylab(expression(CH[4]~diffusive~flux~(mmol~m^-2~d^-1)))+
  ylab("")+
  ggtitle("(g)")+
  theme_classic()+
  theme(text = element_text(size = 7))+
  theme(axis.line.x.bottom=element_line())+
  theme(axis.ticks.x = element_line())+
  theme(axis.line.y.left=element_line())+
  theme(axis.ticks.y = element_line())+
  theme(legend.position = "none")

TP_flux <- ggplot(flux_supp2, aes(x=TP, y=Diffusive_CH4_Flux_Mean)) +
  #geom_point(size = 0.5, color = "#a4ac86", alpha = 0.15)+
  geom_bin2d(bins = 60) +
  scale_fill_scico(limits = c(1, 15),palette = "bamako") +
  scale_x_log10(limits = c(0.01, 1000), labels = trans_format("log10", math_format(10^.x)))+
  scale_y_log10(limits = c(0.0001, 100), labels = trans_format("log10", math_format(10^.x)))+
  xlab(~ paste("Total P (", mu, "mol L"^-1, ")" ))+
  #ylab(expression(CH[4]~diffusive~flux~(mmol~m^-2~d^-1)))+
  ylab("")+
  ggtitle("(h)")+
  theme_classic()+
  theme(text = element_text(size = 7))+
  theme(axis.line.x.bottom=element_line())+
  theme(axis.ticks.x = element_line())+
  theme(axis.line.y.left=element_line())+
  theme(axis.ticks.y = element_line())+
  theme(legend.key.size = unit(0.275, 'cm'))

all_flux_plots <- DO_flux + DOC_flux + TN_flux + TP_flux +
  plot_layout(ncol = 4)

all <-  all_conc_plots / all_flux_plots
ggsave("meth graphs/Fig13_v2.png", 
       width = 6, 
       height = 3 , 
       units = "in",
       dpi = 500)



###########
#Figure 14
###########

conc_sites <- conc_CH4 %>% 
  left_join(sites_out, by = "Site_ID")

Q_conc <- conc_sites %>%
  filter(Q > 0, CH4mean > 0) %>%
  add_count(Site_ID) %>%
  #filter(n > 30)  %>%
  ggplot() +
  geom_point(aes(x=Q, y=CH4mean),size = 0.5, color = "#ff9f1c", alpha = .1)+
  scale_x_log10(label=trans_format("log10",math_format(10^.x)),
                breaks = c(0.0001, 0.01, 1, 100, 10000, 1000000))+
  scale_y_log10(limits = c(0.0001, 1000), labels = trans_format("log10", math_format(10^.x)))+
  xlab(expression(Discharge~(m^3~s^-1)))+
  ylab(~ paste("CH"[4] , " (", mu, "mol L"^-1, ")" ))+
  theme_classic()+
  theme(text = element_text(size = 7))+
  theme(axis.line.x.bottom=element_line())+
  theme(axis.ticks.x = element_line())+
  theme(axis.line.y.left=element_line())+
  theme(axis.ticks.y = element_line())+
  theme(legend.position = "none")+
  labs(tag = "(a)")


#57 sites with n > 30
mycolors <- colorRampPalette(RColorBrewer::brewer.pal(8, "Set1"))(57)
conc_sites$Site_ID <- as.character(conc_sites$Site_ID)

conc_q <- 
  conc_sites %>% 
  filter(Q > 0, CH4mean > 0) %>% 
  ggplot()+
  geom_point(data = conc_sites %>% 
               filter(Q > 0, CH4mean > 0) %>%
               add_count(Site_ID) %>%
               filter(n > 30),
             aes(Q, CH4mean, color= Site_ID), size = 0.5,alpha = .1)+
  geom_smooth(data = conc_sites %>% 
                filter(Q > 0, CH4mean > 0) %>%
                add_count(Site_ID) %>%
                filter(n > 30),
              aes(Q, CH4mean, color= Site_ID, group= Site_ID), linewidth = 0.5, se=FALSE, method = "lm")+
  scale_color_manual(values = mycolors)+
  scale_x_log10(label=trans_format("log10",math_format(10^.x)),
                breaks = c(0.0001, 0.01, 1, 100, 10000, 1000000))+
  scale_y_log10(label=trans_format("log10",math_format(10^.x)),
                limits=c(0.0001, 1000))+
  theme_classic()+
  theme(text = element_text(size = 8))+
  theme(legend.position = "none")+
  xlab(expression(Discharge~(m^3~s^-1)))+
  ylab(~ paste("CH"[4] , " (", mu, "mol L"^-1, ")" ))+
  labs(tag = "(b)")

Qplots <- Q_conc + conc_q
ggsave("meth graphs/Fig14.png", 
       width = 6, 
       height = 2.5, 
       units = "in",
       dpi = 500)

long_conc <- conc_sites %>% 
  filter(Q > 0, CH4mean > 0) %>%
  add_count(Site_ID) %>%
  filter(n > 30)

x <- long_conc %>%
  split(.$Site_ID) %>% #split by grouping variable
  map(~ lm(log10(CH4mean) ~ log10((Q)), data = .)) %>%
  map_df(broom::glance, .id='Site_ID') %>%
  select(Site_ID, r.squared, p.value, nobs)

long1 <- data.table(long_conc)
long1_reg <-long1[,as.list(coef(lm(log10(CH4mean) ~ log10(Q)))), by = Site_ID]

long1_lm_results <- left_join(long1_reg, x)
colnames(long1_lm_results)[3] = "Slope"
long1_lm_results <- mutate(long1_lm_results, Sig = ifelse(p.value <0.05, "yes", "no"))
long1_lm_results <- mutate(long1_lm_results, Slope = ifelse(Slope <0, "negative", "positive"))

write.csv(long1_lm_results, file = "meth data/Q_conc_LMresults.csv", row.names = FALSE)


###########
#Figure 14
###########

CH4_siteavg_conc <-separate_rows(CH4_siteavg_conc, Channel_type, sep = ", ") 
CH4_siteavg_conc <- CH4_siteavg_conc %>% replace_na(list(Channel_type = "NORM"))

siteavg_count <- CH4_siteavg_conc %>% group_by(Channel_type) %>% 
  summarise(npertype = n()) 
#add a column specifying the position of site count data on the plot
siteavg_count <- siteavg_count %>% mutate(ch4 = 3.6)

siteavg_count$Channel_type <- as.factor(siteavg_count$Channel_type)
siteavg_count$Channel_type <-factor(siteavg_count$Channel_type, levels = c("WS", "TH", "SP",
                                                                           "PS", "PI",
                                                                           "IMP", "GT", "FP",
                                                                           "DIT", "DD", "DC",
                                                                           "CH", "CAN", "NORM"))


CH4_siteavg_conc$Channel_type <- as.factor(CH4_siteavg_conc$Channel_type)
CH4_siteavg_conc$Channel_type <-factor(CH4_siteavg_conc$Channel_type, levels = c("WS", "TH", "SP",
                                                                       "PS", "PI",
                                                                       "IMP", "GT", "FP",
                                                                       "DIT", "DD", "DC",
                                                                       "CH", "CAN", "NORM"))

#hline position:
norm_c <- CH4_siteavg_conc %>% 
  filter(Channel_type == "NORM")
log10(median(norm_c$avg))

conc_type <- ggplot(CH4_siteavg_conc, aes(x = Channel_type, y = log10(avg)))+
  geom_boxplot(fill = "#ff9f1c")+
  ylab(~ paste("CH"[4] , " (", mu, "mol L"^-1, ")" ))+
  scale_y_continuous(limits = c(-4, 4), breaks=seq(-4,4,by = 2),labels = math_format(10^.x))+
  xlab("Channel type")+
  coord_flip()+
  geom_text(size = 3, data = siteavg_count, aes(x = Channel_type, y = ch4, label = npertype))+
  theme_bw() +
  theme(panel.grid.major = element_blank(), panel.grid.minor = element_blank())+
  theme(axis.title = element_text(size = 12))+
  theme(axis.text.y = element_text(size = 8.5))+
  geom_hline(yintercept = -0.7635971, linewidth = 0.7,  
             color = "black")+
  labs(tag = "(a)")

###flux
CH4_avg_flux <-separate_rows(CH4_siteavg_flux, Channel_type, sep = ", ")
CH4_avg_flux <- CH4_avg_flux %>% replace_na(list(Channel_type = "NORM"))
CH4_avg_f <- CH4_avg_flux[, c(1, 2, 15)]


flux_chan_count <- CH4_avg_f %>% 
  group_by(Channel_type) %>% 
  summarise(npertype = n()
  )

flux_chan_count <- flux_chan_count %>% 
  add_row(Channel_type = "TH" , npertype = 0)
flux_chan_count <- mutate(flux_chan_count, ch4 = 4.4)

flux_chan_count$Channel_type <- as.factor(flux_chan_count$Channel_type)
flux_chan_count$Channel_type <- factor(flux_chan_count$Channel_type, 
                                       levels = c("WS", "TH", "SP", "PS", "PI",
                                                  "IMP", "GT", "FP", "DIT", "DD", "DC",
                                                  "CH", "CAN", "NORM"))

#adding a row in to represent "TH" channels; there are no flux data for this type
TH<- c(99999, -0.3436762, "TH")
CH4_avg_f <- rbind(CH4_avg_f, TH)
CH4_avg_f$AvgFlux <- as.numeric(CH4_avg_f$AvgFlux)
CH4_avg_f$Channel_type <- as.factor(CH4_avg_f$Channel_type)
CH4_avg_f$Channel_type <- factor(CH4_avg_f$Channel_type, levels = c("WS", "TH", "SP", "PS", "PI",
                                                                    "IMP", "GT", "FP","DIT", "DD", "DC",
                                                                    "CH", "CAN", "NORM"))
                                
#hline position:
norm_f <- CH4_avg_f %>% filter(Channel_type == "NORM")
log10(median(norm_f$AvgFlux))

flux_type <-ggplot(CH4_avg_f, aes(x = Channel_type, y = log10(AvgFlux)))+
  geom_boxplot(fill = "#a4ac86")+
  ylab(expression(CH[4]~diffusive~flux~(mmol~m^-2~d^-1)))+
  scale_y_continuous(limits = c(-5, 5), breaks=seq(-5,5,by = 2),labels = math_format(10^.x))+
  xlab("Channel type")+
  coord_flip()+
  geom_text(size = 3, data = flux_chan_count, aes(x = Channel_type, y = ch4, label = npertype))+
  theme_bw()+
  theme(panel.grid.major = element_blank(), panel.grid.minor = element_blank())+
  theme(axis.title = element_text(size = 12))+
  theme(axis.text.y = element_text(size = 8.5))+
  geom_hline(yintercept = -0.3436762, linewidth = 0.9,  
             color = "black")+
  labs(tag = "(b)")

fig14 <- conc_type/flux_type
ggsave("meth graphs/Fig14.png", 
       width = 6, 
       height = 5, 
       units = "in",
       dpi = 500)

##Kruskal-Wallis test for channel types
#Concentration
channel_type_C_median <- CH4_siteavg_conc %>% group_by(Channel_type) %>% summarise(median_channel_CH4 = median(avg))

#remove SP sites because of low sample count
siteavg_conc_kw <- CH4_siteavg_conc %>% filter(Channel_type != "SP")
kw_conc <- kruskal.test(avg ~ Channel_type, data = siteavg_conc_kw)
conc_pairs <-pairwise.wilcox.test(siteavg_conc_kw$avg, CH4_siteavg_conc$Channel_type,
                             p.adjust.method = "BH")

#Flux
channel_type_F_median <- CH4_avg_f %>% group_by(Channel_type) %>% summarise(median_channel_F_CH4 = median(AvgFlux))

#remove FP, GT, PI, SP, TH because of low sample counts
avg_f_kw <- CH4_avg_f %>% 
  filter(!Channel_type %in% c("FP", "GT", "PI", "SP", "TH"))
kw_flux <- kruskal.test(AvgFlux ~ Channel_type, data = avg_f_kw)
flux_pairs <- pairwise.wilcox.test(avg_f_kw$AvgFlux, avg_f_kw$Channel_type,
                                 p.adjust.method = "BH")




#########
#Table S5
#########

##NOTE- continent locations are not included in sites_out; 
##these were taken from our original data entry process.
##conc_CH4 and flux-related df's are generated starting on line ~32
continent <- read.csv("meth data/sites_continents.csv")
site_count <- continent %>%
  group_by(Continent) %>%
  summarise(
    across(where(is.numeric), ~length(which(!is.na(.x))), 
           .names = "{col}_n"))

site_count <- site_count %>% mutate(percent_sites = (Site_ID_n/sum(Site_ID_n)*100))
site_count <- site_count %>% mutate(percent_order = (Strahler_order_n/sum(Site_ID_n)*100))
site_count <- site_count %>% mutate(percent_catch_size = (Catchment_size_km2_n/sum(Site_ID_n)*100))

conc_CH4$Site_ID <- as.numeric(conc_CH4$Site_ID)
CH4_counts <- left_join(conc_CH4, continent, by = "Site_ID") 
CH4_counts <- CH4_counts %>% group_by(Continent) %>%  
  summarise(count = n())
CH4_counts <- rename(CH4_counts, CH4conc = count)

conc_CO2$Site_ID <- as.numeric(conc_CO2$Site_ID)
CO2_counts <- left_join(conc_CO2, continent, by = "Site_ID") 
CO2_counts <- CO2_counts %>% group_by(Continent) %>%  
  summarise(count = n())
CO2_counts <- rename(CO2_counts, CO2conc = count)

conc_N2O$Site_ID <- as.numeric(conc_N2O$Site_ID)
N2O_counts <- left_join(conc_N2O, continent, by = "Site_ID") 
N2O_counts <- N2O_counts %>% group_by(Continent) %>%  
  summarise(count = n())
N2O_counts <- rename(N2O_counts, N2Oconc = count)

conc_counts1 <- left_join(CH4_counts, CO2_counts)
conc_counts_all <- left_join(conc_counts1, N2O_counts)
conc_counts_all[is.na(conc_counts_all)] <- 0

conc_counts_all <- conc_counts_all %>% mutate(CH4conc_pct = 
                                                (CH4conc/sum(CH4conc)*100))
conc_counts_all <- conc_counts_all %>% mutate(CO2conc_pct = 
                                                (CO2conc/sum(CO2conc)*100))
conc_counts_all <- conc_counts_all %>% mutate(N2Oconc_pct = 
                                                (N2Oconc/sum(N2Oconc)*100))


#check str() for Site_ID's
d_flux_CH4$Site_ID <-as.numeric(d_flux_CH4$Site_ID)
e_flux_CH4$Site_ID <- as.numeric(e_flux_CH4$Site_ID)
t_flux_CH4$Site_ID <- as.numeric(t_flux_CH4$Site_ID)
flux_CO2$Site_ID <- as.numeric(flux_CO2$Site_ID)
flux_N2O$Site_ID <- as.numeric(flux_N2O$Site_ID)


d_flux_count <-left_join(d_flux_CH4,  continent, by = "Site_ID") %>% 
  group_by(Continent) %>%  
  summarise(count = n())
d_flux_count <- d_flux_count %>% rename(CH4diff_n = count)

e_flux_count <-left_join(e_flux_CH4, continent, by = "Site_ID") %>% 
  group_by(Continent) %>%  
  summarise(count = n())
e_flux_count <- e_flux_count %>% rename(CH4eb_n = count)

t_flux_count <-left_join(t_flux_CH4, continent, by = "Site_ID") %>% 
  group_by(Continent) %>%  
  summarise(count = n())
t_flux_count <- t_flux_count %>% rename(CH4total_n = count)


CO2_flux_count <- (left_join(flux_CO2, continent, by = "Site_ID")) %>% 
  group_by(Continent) %>% 
  summarise(count = n())
CO2_flux_count <- CO2_flux_count %>% rename(CO2flux_n = count)

N2O_flux_count<- (left_join(flux_N2O, continent, by = "Site_ID")) %>% 
  group_by(Continent) %>% 
  summarise(count = n())
N2O_flux_count <- N2O_flux_count %>% rename(N2Oflux_n = count)


flux_n1 <-full_join(d_flux_count, e_flux_count, by = "Continent")
flux_n2 <- left_join(flux_n1, t_flux_count, by = "Continent")
flux_n3 <- left_join(flux_n2, CO2_flux_count, by = "Continent")
flux_count_all <- left_join(flux_n3, N2O_flux_count, by = "Continent")
flux_count_all[is.na(flux_count_all)] <- 0


flux_count_all <- flux_count_all %>% mutate(CH4diff_pct = 
                                                (CH4diff_n/sum(CH4diff_n)*100))
flux_count_all <- flux_count_all %>% mutate(CH4deb_pct = 
                                              (CH4eb_n/sum(CH4eb_n)*100))
flux_count_all <- flux_count_all %>% mutate(CH4total_pct = 
                                              (CH4total_n/sum(CH4total_n)*100))

flux_count_all <- flux_count_all %>% mutate(CO2flux_pct = 
                                                (CO2flux_n/sum(CO2flux_n)*100))
flux_count_all <- flux_count_all %>% mutate(N2Oflux_pct = 
                                                (N2Oflux_n/sum(N2Oflux_n)*100))


#note that this does not handle counting well for sites with medians but no means
conc_out$Site_ID <- as.numeric(conc_out$Site_ID)
conc_out$pH <- as.numeric(conc_out$pH)
wchems <- conc_out[, c(1,2,3,4,26:38)]
wchems <- left_join(wchems, continent, by = "Site_ID")
wchem_count <- wchems %>%
  group_by(Continent) %>%
  summarise(
    #across(where(is.numeric), list(mean = mean), 
    #       .names = "{.col}_{.fn}"), 
    across(where(is.numeric), ~length(which(!is.na(.x))), 
           .names = "{col}_n"))

wchem_count <- wchem_count[, c(1, 4:16)]

ac <- left_join(site_count, conc_counts_all)
ac2 <- left_join(ac, flux_count_all)
all_counts <-left_join(ac2, wchem_count)
all_counts[is.na(all_counts)] <- 0
all_counts <- all_counts %>%  bind_rows(summarise(.,
                                                  across(where(is.numeric), sum),
                                                  across(where(is.character), ~"Total")))

write.csv(all_counts, file = "meth data/count_by_continent.csv", row.names = FALSE)

#########



